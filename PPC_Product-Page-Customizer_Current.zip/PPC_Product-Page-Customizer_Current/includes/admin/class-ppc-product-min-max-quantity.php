<?php

// includes/admin/class-ppc-product-min-max-fields.php
if (!defined('ABSPATH')) exit;

class PPC_Product_Min_Max_Quantity
{
    public function __construct()
    {
        // Only validate if global feature is enabled
        if ('yes' === get_option('ppc_enable_min_max_order', 'no')) {
            // Frontend validation hooks
            add_filter('woocommerce_add_to_cart_validation', [$this, 'validate_quantity'], 10, 3);
            add_filter('woocommerce_quantity_input_args', [$this, 'set_input_quantity_limits'], 10, 2);

            // Admin product tab hooks
            add_filter('woocommerce_product_data_tabs', [$this, 'add_min_max_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'add_min_max_fields']);
            add_action('woocommerce_process_product_meta', [$this, 'save_min_max_fields']);
        }
    }

    /**
     * Add Min/Max Quantity tab to Product Data tabs
     */
    public function add_min_max_tab($tabs) {
        $tabs['ppc_min_max'] = [
            'label'    => __('Min/Max Quantity', 'product-page-customizer'),
            'target'   => 'ppc_min_max_product_data',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 85,
        ];
        return $tabs;
    }

    /**
     * Add fields to Min/Max Quantity tab
     */
    public function add_min_max_fields() {
        global $post;

        echo '<div id="ppc_min_max_product_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        // Minimum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_min_qty',
            'label'       => __('Minimum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set Minimum Quantity for this product.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        // Maximum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_max_qty',
            'label'       => __('Maximum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set Maximum Quantity for this product.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        echo '</div>';
        echo '</div>';
    }

    /**
     * Save Min/Max Quantity fields
     */
    public function save_min_max_fields($post_id) {
        // Save minimum quantity
        if (isset($_POST['_ppc_min_qty'])) {
            $min_qty = absint($_POST['_ppc_min_qty']);
            if ($min_qty < 1) $min_qty = 1;
            update_post_meta($post_id, '_ppc_min_qty', $min_qty);
        }

        // Save maximum quantity
        if (isset($_POST['_ppc_max_qty'])) {
            $max_qty = absint($_POST['_ppc_max_qty']);
            if ($max_qty < 1) $max_qty = 1;
            update_post_meta($post_id, '_ppc_max_qty', $max_qty);
        }
    }

    /**
     * Validate quantity against min/max limits
     */
    public function validate_quantity($passed, $product_id, $quantity)
    {
        $min = get_post_meta($product_id, '_ppc_min_qty', true);
        $max = get_post_meta($product_id, '_ppc_max_qty', true);

        if ($min && $quantity < $min) {
            wc_add_notice(
                sprintf(__('The minimum quantity allowed for this product is %d.', 'product-page-customizer'), $min),
                'error'
            );
            return false;
        }

        if ($max && $quantity > $max) {
            wc_add_notice(
                sprintf(__('The maximum quantity allowed for this product is %d.', 'product-page-customizer'), $max),
                'error'
            );
            return false;
        }

        return $passed;
    }

    /**
     * Set quantity input limits
     */
    public function set_input_quantity_limits($args, $product)
    {
        $min = get_post_meta($product->get_id(), '_ppc_min_qty', true);
        $max = get_post_meta($product->get_id(), '_ppc_max_qty', true);

        if ($min) {
            $args['min_value'] = $min;
        }

        if ($max) {
            $args['max_value'] = $max;
        }

        return $args;
    }
}

new PPC_Product_Min_Max_Quantity();
