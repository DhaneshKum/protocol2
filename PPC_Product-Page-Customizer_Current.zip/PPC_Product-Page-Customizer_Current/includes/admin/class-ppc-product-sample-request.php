<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Sample_Request
{
    public function __construct()
    {
        // Only add product tab if sample request feature is enabled
        if ('yes' === get_option('enable_sample_request', 'no')) {
            add_filter('woocommerce_product_data_tabs', [$this, 'add_sample_request_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'add_sample_request_fields']);
            add_action('woocommerce_process_product_meta', [$this, 'save_sample_request_fields']);
        }
    }

    /**
     * Add Sample Request tab to Product Data tabs
     */
    public function add_sample_request_tab($tabs)
    {
        $tabs['ppc_sample_request'] = [
            'label'    => __('Sample Request', 'product-page-customizer'),
            'target'   => 'ppc_sample_request_data',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 85,
        ];
        return $tabs;
    }

    /**
     * Add fields to Sample Request tab
     */
    public function add_sample_request_fields()
    {
        global $post;

        echo '<div id="ppc_sample_request_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        // Enable Sample Request for this product
        woocommerce_wp_checkbox([
            'id'          => '_ppc_enable_sample_request',
            'label'       => __('Enable Sample Request', 'product-page-customizer'),
            'description' => __('Enable sample request for this product.', 'product-page-customizer'),
            'desc_tip'    => true,
        ]);

        echo '</div>';
        echo '</div>';
    }

    /**
     * Save Sample Request fields
     */
    public function save_sample_request_fields($post_id)
    {
        $enable_sample = isset($_POST['_ppc_enable_sample_request']) ? 'yes' : 'no';
        update_post_meta($post_id, '_ppc_enable_sample_request', $enable_sample);
    }
}

new PPC_Product_Sample_Request(); 