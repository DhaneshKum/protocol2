<?php
// includes/admin/class-ppc-admin-settings.php
if (!defined('ABSPATH')) exit;

class PPC_Admin_Settings
{
    public function __construct()
    {
        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_ppc_settings', [$this, 'display_settings']);
        add_action('woocommerce_update_options_ppc_settings', [$this, 'save_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
    }

    public function add_settings_tab($settings_tabs)
    {
        $settings_tabs['ppc_settings'] = __('Wholesale Product Page Customizer', 'product-page-customizer');
        return $settings_tabs;
    }

    public function get_settings()
    {
        $settings = [

            // Section 1: Attachments
            [
                'name' => __('Product PDF Settings', 'product-page-customizer'),
                'type' => 'title',
                'desc' => 'Upload and control product user guide PDFs.',
                'id'   => 'ppc_pdf_settings_title'
            ],
            [
                'name'    => __('Product Pdf Uploader', 'product-page-customizer'),
                'desc'    => __('Want to add attachments on the individual product page.', 'product-page-customizer'),
                'id'      => 'ppc_enable_pdf',
                'type'    => 'checkbox',
                'default' => 'no',
                'desc_tip' => true,
            ],
            ['type' => 'sectionend', 'id' => 'ppc_pdf_settings_title'],

            // Section 2: Min/Max
            [
                'name' => __('Min/Max Order Quantity', 'product-page-customizer'),
                'type' => 'title',
                'desc' => 'Set minimum and maximum order quantities for products.',
                'id'   => 'ppc_min_max_order_settings_title'
            ],
            [
                'name'    => __('Globally Set Min/Max Order Quantity', 'product-page-customizer'),
                'desc'    => __('Want to set globally minimum and maximum order quantities for products.', 'product-page-customizer'),
                'id'      => 'ppc_enable_min_max_order',
                'type'    => 'checkbox',
                'default' => 'no'
            ],
            [
                'name'     => __('Minimum Quantity', 'product-page-customizer'),
                'desc_tip' => __('Minimum quantity must be greater than 0.', 'product-page-customizer'),
                'id'       => 'ppc_min_quantity',
                'type'     => 'number',
                'class'    => 'ppc_min_max_fields',
                'css'      => 'width:50px;',
                'default'  => 1,
                'custom_attributes' => ['min' => 1]
            ],
            [
                'name'     => __('Maximum Quantity', 'product-page-customizer'),
                'desc_tip' => __('Maximum quantity must be greater than 0.', 'product-page-customizer'),
                'id'       => 'ppc_max_quantity',
                'type'     => 'number',
                'class'    => 'ppc_min_max_fields',
                'css'      => 'width:50px;',
                'default'  => 10,
                'custom_attributes' => ['min' => 1]
            ],
            ['type' => 'sectionend', 'id' => 'ppc_min_max_order_settings_title'],

            // Section 3: You Save
            [
                'name' => __('"You Save" Message', 'product-page-customizer'),
                'type' => 'title',
                'desc' => __('Display a custom "You Save" message showing the discount amount on product pages.', 'product-page-customizer'),
                'id'   => 'ppc_you_save_message_settings_title'
            ],
            [
                'name'    => __('Enable "You Save" Message', 'product-page-customizer'),
                'desc'    => __('Enable this feature to display a custom "You Save" message on product and shop pages.', 'product-page-customizer'),
                'id'      => 'ppc_enable_you_save',
                'type'    => 'checkbox',
                'default' => 'no'
            ],
            [
                'name'    => __('Set Per Product', 'product-page-customizer'),
                'desc'    => __('Enable this to define custom messages per product from the product editor.', 'product-page-customizer'),
                'id'      => 'ppc_you_save_set_individual',
                'type'    => 'checkbox',
                'default' => 'no',
                'class'   => 'ppc_you_save_mode_checkbox'
            ],
            [
                'name'    => __('Set Globally', 'product-page-customizer'),
                'desc'    => __('Enable this to use the global message and display location defined below.', 'product-page-customizer'),
                'id'      => 'ppc_you_save_set_global',
                'type'    => 'checkbox',
                'default' => 'yes',
                'class'   => 'ppc_you_save_mode_checkbox'
            ],
            [
                'name' => __('Global Custom Message', 'product-page-customizer'),
                'id'   => 'ppc_you_save_custom_msg',
                'type' => 'text',
                'css'  => 'min-width: 300px;',
                'default' => __('You Save', 'product-page-customizer'),
                'desc_tip' => true,
                'desc' => __('This is the text prefix for the savings amount. Example: "You Save ₨2"', 'product-page-customizer'),
                'class' => 'ppc_global_only'
            ],
            [
                'name' => __('Display Position', 'product-page-customizer'),
                'id'   => 'ppc_you_save_display_position',
                'type' => 'select',
                'options' => [
                    'after_cart' => __('After Add to Cart Button (default)', 'product-page-customizer'),
                    'before_cart' => __('Before Add to Cart Button', 'product-page-customizer'),
                ],
                'default' => 'after_cart',
                'desc' => __('Choose where to display the "You Save" message on the product page.', 'product-page-customizer'),
                'class' => 'ppc_global_only'
            ],
            ['type' => 'sectionend', 'id' => 'ppc_you_save_message_settings_title'],

            // Section 4: Variants Display Settings
            [
                'name' => __('Variants Display Settings', 'product-page-customizer'),
                'type' => 'title',
                'desc' => __('Control how product variants are displayed on product pages.', 'product-page-customizer'),
                'id'   => 'ppc_variants_display_settings_title'
            ],
            [
                'name'    => __('Enable Variants Table', 'product-page-customizer'),
                'desc'    => __('Enable variants table display on product pages.', 'product-page-customizer'),
                'id'      => 'ppc_enable_variants_table',
                'type'    => 'checkbox',
                'default' => 'no'
            ],
            [
                'name'    => __('Set Per Product', 'product-page-customizer'),
                'desc'    => __('Enable this to control variants table display per product.', 'product-page-customizer'),
                'id'      => 'ppc_variants_set_individual',
                'type'    => 'checkbox',
                'default' => 'no',
                'class'   => 'ppc_variants_mode_checkbox'
            ],
            [
                'name'    => __('Set Globally', 'product-page-customizer'),
                'desc'    => __('Enable this to use global settings for all products.', 'product-page-customizer'),
                'id'      => 'ppc_variants_set_global',
                'type'    => 'checkbox',
                'default' => 'yes',
                'class'   => 'ppc_variants_mode_checkbox'
            ],
            ['type' => 'sectionend', 'id' => 'ppc_variants_display_settings_title'],

            // Section 5: Product Sample Request
            [
                'title' => __('Request for Samples', 'woocommerce'),
                'type'  => 'title',
                'id'    => 'sample_settings_title'
            ],
            [
                'title'    => __('Product Sample Requests', 'woocommerce'),
                'desc'     => __('Allow users to request a sample product.', 'woocommerce'),
                'id'       => 'enable_sample_request',
                'default'  => 'no',
                'type'     => 'checkbox'
            ],
            [
                'title'    => __('Set Custom Label', 'woocommerce'),
                'desc_tip' => __('Set button label text for requesting a sample.', 'woocommerce'),
                'id'       => 'sample_button_label',
                'default'  => 'Request For Sample',
                'type'     => 'text'
            ],
            [
                'type' => 'sectionend',
                'id'   => 'sample_settings_title'
            ]
        ];

        return apply_filters('ppc_admin_settings', $settings);
    }

    public function display_settings()
    {
        woocommerce_admin_fields($this->get_settings());
    }

    public function save_settings()
    {
        woocommerce_update_options($this->get_settings());
    }

    public function enqueue_admin_scripts($hook)
    {
        if ($hook !== 'woocommerce_page_wc-settings') return;
        if (!isset($_GET['tab']) || $_GET['tab'] !== 'ppc_settings') return;

        // Min/max script
        wp_enqueue_script(
            'ppc-settings-toggle-js',
            plugin_dir_url(__FILE__) . '../../assets/admin/js/ppc-min-max-toggle.js',
            ['jquery'],
            '1.0',
            true
        );

        // You Save toggle logic
        wp_enqueue_script(
            'ppc-admin-script',
            plugin_dir_url(__FILE__) . '../../assets/admin/js/ppc-save-message.js',
            ['jquery'],
            '1.0',
            true
        );

        // Variants toggle logic
        wp_enqueue_script(
            'ppc-variants-toggle-js',
            plugin_dir_url(__FILE__) . '../../assets/admin/js/ppc-variants-toggle.js',
            ['jquery'],
            '1.0',
            true
        );

        // Sample Request toggle logic
        wp_enqueue_script(
            'ppc-sample-request-js',
            plugin_dir_url(__FILE__) . '../../assets/admin/Js/ppc-sample-request.js',
            ['jquery'],
            '1.0',
            true
        );
    }
}

new PPC_Admin_Settings();
