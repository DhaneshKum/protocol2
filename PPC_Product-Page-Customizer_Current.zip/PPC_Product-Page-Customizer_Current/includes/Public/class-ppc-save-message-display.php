<?php
// includes/public/class-ppc-save-message-display.php
if (!defined('ABSPATH')) exit;

class PPC_Save_Message_Display
{

    public function __construct()
    {
        add_action('woocommerce_before_add_to_cart_button', [$this, 'maybe_display_message_before'], 5);
        add_action('woocommerce_after_add_to_cart_button', [$this, 'maybe_display_message_after'], 5);
    }

    public function maybe_display_message_before()
    {
        $this->output_message('before_cart');
    }

    public function maybe_display_message_after()
    {
        $this->output_message('after_cart');
    }

    private function output_message($position)
    {
        global $product;

        if (!$product || !$product->is_on_sale()) {
            return;
        }

        $product_id = $product->get_id();
        $regular_price = (float) $product->get_regular_price();
        $sale_price    = (float) $product->get_sale_price();
        $saved_amount  = wc_price($regular_price - $sale_price);

        $enable_global     = get_option('ppc_you_save_set_global') === 'yes';
        $enable_individual = get_option('ppc_you_save_set_individual') === 'yes';

        $message = '';

        // Show Individual Message
        if ($enable_individual) {
            $individual_position = get_post_meta($product_id, '_ppc_individual_position', true);
            if ($individual_position !== $position) return;

            $custom_msg = get_post_meta($product_id, '_ppc_individual_custom_msg', true);
            if (!$custom_msg) return;

            $message = esc_html($custom_msg) . ' ' . $saved_amount;
        }

        // Show Global Message (only if individual is disabled)
        elseif ($enable_global) {
            $global_position = get_option('ppc_you_save_display_position', 'after_cart');
            if ($global_position !== $position) return;

            $prefix = get_option('ppc_you_save_custom_msg', 'You Save');
            $message = esc_html($prefix) . ' ' . $saved_amount;
        }

        if ($message) {
            echo '<div class="ppc-you-save-message" style="margin:10px 0;font-weight:bold;color:#0a0;">' . $message . '</div>';
        }
    }
}

new PPC_Save_Message_Display();
