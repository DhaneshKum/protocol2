<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Sample_Display
{
    public function __construct()
    {
        // Move sample request button to be right after add to cart button
        add_action('woocommerce_after_add_to_cart_button', [$this, 'display_sample_request_button'], 1);
        
        // Handle AJAX request for adding sample to cart
        add_action('wp_ajax_add_sample_to_cart', [$this, 'add_sample_to_cart']);
        add_action('wp_ajax_nopriv_add_sample_to_cart', [$this, 'add_sample_to_cart']);
        
        // Modify cart item data and display
        add_filter('woocommerce_add_cart_item_data', [$this, 'add_sample_cart_item_data'], 10, 3);
        add_filter('woocommerce_cart_item_name', [$this, 'modify_cart_item_name'], 99, 3);
        add_action('woocommerce_before_calculate_totals', [$this, 'set_sample_price'], 99);
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Display sample request button
     */
    public function display_sample_request_button()
    {
        global $product;

        // Check if sample request is enabled globally
        if ('yes' !== get_option('enable_sample_request', 'no')) {
            return;
        }

        // Check if sample request is enabled for this product
        if ('yes' !== get_post_meta($product->get_id(), '_ppc_enable_sample_request', true)) {
            return;
        }

        // Get custom button label
        $button_label = get_option('sample_button_label', 'Request For Sample');

        // Output the button
        ?>
        <button type="button" class="button alt" id="sample-request-btn" 
                data-product_id="<?php echo esc_attr($product->get_id()); ?>"
                data-nonce="<?php echo wp_create_nonce('add_sample_to_cart'); ?>">
            <?php echo esc_html($button_label); ?>
        </button>
        <?php
    }

    /**
     * Add sample data to cart item
     */
    public function add_sample_cart_item_data($cart_item_data, $product_id, $variation_id)
    {
        if (isset($_POST['action']) && $_POST['action'] === 'add_sample_to_cart') {
            $cart_item_data['is_sample'] = 'yes';
            $cart_item_data['unique_key'] = uniqid('sample_');
        }
        return $cart_item_data;
    }

    /**
     * Handle adding sample to cart via AJAX
     */
    public function add_sample_to_cart()
    {
        check_ajax_referer('add_sample_to_cart', 'nonce');

        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;

        if (!$product_id) {
            wp_send_json_error(['message' => __('Invalid product', 'product-page-customizer')]);
        }

        // Remove any existing samples of this product
        $cart = WC()->cart;
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (isset($cart_item['is_sample']) && $cart_item['is_sample'] === 'yes' 
                && $cart_item['product_id'] === $product_id) {
                $cart->remove_cart_item($cart_item_key);
            }
        }

        // Add to cart
        $added = WC()->cart->add_to_cart($product_id, 1);

        if ($added) {
            wp_send_json_success([
                'message' => __('Sample added to cart', 'product-page-customizer'),
                'cart_url' => wc_get_cart_url()
            ]);
        } else {
            wp_send_json_error(['message' => __('Failed to add sample to cart', 'product-page-customizer')]);
        }
    }

    /**
     * Modify cart item name to add Sample text
     */
    public function modify_cart_item_name($name, $cart_item, $cart_item_key)
    {
        if (!empty($cart_item['is_sample']) && $cart_item['is_sample'] === 'yes') {
            $name .= ' <strong>- ' . esc_html__('Sample', 'product-page-customizer') . '</strong>';
        }
        return $name;
    }

    /**
     * Set price to zero for sample items
     */
    public function set_sample_price($cart)
    {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (!empty($cart_item['is_sample']) && $cart_item['is_sample'] === 'yes') {
                $product = $cart_item['data'];
                $product->set_price(0);
                $product->set_regular_price(0);
                $product->set_sale_price(0);
                
                // Force quantity to 1
                $cart->set_quantity($cart_item_key, 1, false);
            }
        }
    }

    /**
     * Enqueue necessary scripts and styles
     */
    public function enqueue_scripts()
    {
        if (!is_product()) {
            return;
        }

        // Enqueue CSS
        wp_enqueue_style(
            'ppc-sample-request',
            PPC_URL . 'assets/public/css/sample-request.css',
            [],
            PPC_VERSION
        );

        // Enqueue JS
        wp_enqueue_script(
            'ppc-sample-request-cart',
            PPC_URL . 'assets/public/js/sample-request-cart.js',
            ['jquery'],
            PPC_VERSION,
            true
        );

        wp_localize_script('ppc-sample-request-cart', 'ppcSampleRequest', [
            'ajaxurl' => admin_url('admin-ajax.php'),
        ]);
    }
}

new PPC_Product_Sample_Display(); 