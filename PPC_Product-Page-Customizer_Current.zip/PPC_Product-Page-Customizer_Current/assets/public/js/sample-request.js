jQuery(document).ready(function($) {
    var modal = $('#sample-request-modal');
    var btn = $('#sample-request-btn');
    var span = $('.close');

    // Open modal
    btn.on('click', function() {
        modal.show();
    });

    // Close modal
    span.on('click', function() {
        modal.hide();
    });

    // Close modal when clicking outside
    $(window).on('click', function(event) {
        if (event.target == modal[0]) {
            modal.hide();
        }
    });

    // Handle form submission
    $('#sample-request-form').on('submit', function(e) {
        e.preventDefault();

        var form = $(this);
        var submitButton = form.find('button[type="submit"]');
        var messageDiv = form.find('.sample-request-message');

        // Remove any existing message
        messageDiv.remove();

        // Disable submit button
        submitButton.prop('disabled', true);

        // Collect form data
        var formData = {
            action: 'sample_request',
            nonce: ppcSampleRequest.nonce,
            product_id: form.find('input[name="product_id"]').val(),
            name: form.find('input[name="name"]').val(),
            email: form.find('input[name="email"]').val(),
            phone: form.find('input[name="phone"]').val(),
            message: form.find('textarea[name="message"]').val()
        };

        // Send AJAX request
        $.post(ppcSampleRequest.ajaxurl, formData, function(response) {
            var messageClass = response.success ? 'sample-request-success' : 'sample-request-error';
            
            // Add message before the submit button
            $('<div class="sample-request-message ' + messageClass + '">' + response.data.message + '</div>')
                .insertBefore(submitButton);

            if (response.success) {
                // Clear form on success
                form[0].reset();
                
                // Close modal after 2 seconds
                setTimeout(function() {
                    modal.hide();
                }, 1000);
            }
        })
        .fail(function() {
            // Show error message if AJAX request fails
            $('<div class="sample-request-message sample-request-error">An error occurred. Please try again.</div>')
                .insertBefore(submitButton);
        })
        .always(function() {
            // Re-enable submit button
            submitButton.prop('disabled', false);
        });
    });
}); 