jQuery(document).ready(function ($) {
    // Enforce mutual exclusivity for variants display settings
    $('#ppc_variants_set_individual').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_global').prop('checked', false);
        }
    });

    $('#ppc_variants_set_global').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_individual').prop('checked', false);
        }
    });

    function toggleVariantsFields() {
        const isEnabled = $('#ppc_enable_variants_table').is(':checked');
        
        // Show/hide the option rows
        $('#ppc_variants_set_individual').closest('tr').toggle(isEnabled);
        $('#ppc_variants_set_global').closest('tr').toggle(isEnabled);
        
        // If disabling, uncheck both options
        if (!isEnabled) {
            $('#ppc_variants_set_individual').prop('checked', false);
            $('#ppc_variants_set_global').prop('checked', false);
        }
    }

    // Initial state
    toggleVariantsFields();

    // Toggle when main checkbox changes
    $('#ppc_enable_variants_table').on('change', toggleVariantsFields);
}); 