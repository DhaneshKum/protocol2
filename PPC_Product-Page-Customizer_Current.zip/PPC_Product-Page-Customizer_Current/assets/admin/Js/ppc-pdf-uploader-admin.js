jQuery(document).ready(function ($) {
    $('.ppc-upload-pdf').click(function (e) {
        e.preventDefault();

        var button = $(this);
        var input = button.prev('input');

        var custom_uploader = wp.media({
            title: 'Select PDF',
            library: {
                type: 'application/pdf'
            },
            button: {
                text: 'Use this PDF'
            },
            multiple: false
        }).on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            input.val(attachment.url);
        }).open();
    });
});
