<?php

/**
 * Plugin Name: Product Page Customizer (Dhanesh)
 * Plugin URI: https://codup.co/
 * Version: 1.1
 * Tested up to: 6.7.1
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 3.0
 * WC tested up to: 9.3.3
 * Author: Dhanesh
 * Author URI: https://codup.co
 * Developer: Dhanesh
 * Developer URI: https://codup.co
 * Text Domain: product-page-customizer
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('PPC_DIR', plugin_dir_path(__FILE__));
define('PPC_URL', plugin_dir_url(__FILE__));
define('PPC_BASENAME', plugin_basename(__FILE__));
define('PPC_VERSION', '1.1');


/** Main Class 
 */
if (!class_exists('PPC_Product_Page_Customizer')) {

    /** Main Class B2B_Products_Page_Customizer */
    class PPC_Product_Page_Customizer
    {
        public function __construct()
        {
            // Check WooCommerce active
            if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
                add_action('admin_notices', function () {
                    echo '<div class="error notice"><p>' . esc_html__('Product Page Customizer requires WooCommerce to be installed and activated.', 'product-page-customizer') . '</p></div>';
                });
                return;
            }

            $this->includes();
        }
        /**
         * Includes
         */
        public function includes()
        {
            // Admin classes
            include_once PPC_DIR . 'includes/admin/class-ppc-admin-settings_tab.php';
            include_once PPC_DIR . 'includes/admin/class-ppc-product-min-max-quantity.php';
            include_once PPC_DIR . 'includes/admin/class-ppc-product-pdf-manager.php';
            include_once PPC_DIR . 'includes/admin/class-ppc-product-sample-request.php';
            include_once PPC_DIR . 'includes/admin/class-ppc-product-save-message.php';
            include_once PPC_DIR . 'includes/admin/class-ppc-product-variants.php';

            // Public classes
            include_once PPC_DIR . 'includes/public/class-ppc-product-pdf-display.php';
            include_once PPC_DIR . 'includes/public/class-ppc-product-sample-display.php';
            include_once PPC_DIR . 'includes/public/class-ppc-product-variants-display.php';
            require_once PPC_DIR . 'includes/public/class-ppc-save-message-display.php';
        }
    }
    new PPC_Product_Page_Customizer();
}
