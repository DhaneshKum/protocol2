﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Inicia Aggregator 1
        Thread aggregatorThread1 = new Thread(() =>
        {
            Aggregator aggregator1 = new Aggregator();
            aggregator1.Start();
        });
        aggregatorThread1.IsBackground = true;
        aggregatorThread1.Start();

        // Inicia Aggregator 2
        Thread aggregatorThread2 = new Thread(() =>
        {
            Aggregator2 aggregator2 = new Aggregator2();
            aggregator2.Start();
        });
        aggregatorThread2.IsBackground = true;
        aggregatorThread2.Start();

        // Aguarda um pouco para garantir que os aggregators estão prontos
        Thread.Sleep(1000);

        // Inicia Wavy 1
        Thread wavyThread1 = new Thread(() =>
        {
            Wavy wavy1 = new Wavy();
            while (true)
            {
                wavy1.GenerateSensorData();
                Thread.Sleep(5000); // Ajuste o intervalo conforme necessário
            }
        });
        wavyThread1.IsBackground = true;
        wavyThread1.Start();

        // Inicia Wavy 2
        Thread wavyThread2 = new Thread(() =>
        {
            Wavy2 wavy2 = new Wavy2();
            while (true)
            {
                wavy2.GenerateSensorData();
                Thread.Sleep(5000); // Ajuste o intervalo conforme necessário
            }
        });
        wavyThread2.IsBackground = true;
        wavyThread2.Start();

        // Mantém o programa rodando
        Console.WriteLine("Pressione ENTER para sair...");
        Console.ReadLine();
    }
}
