﻿using System;
using System.IO;
using System.Threading;

public class Server
{
    public void Start()
    {
        while (true)
        {
            
            string temperatureData = ReadDataFromCsv("temperature.csv");
            string phData = ReadDataFromCsv("ph.csv");
            string humidityData = ReadDataFromCsv("humidity.csv");
            string swellData = ReadDataFromCsv("swell.csv");
            string gpsData = ReadDataFromCsv("gps.csv");

            
            Console.WriteLine($"Temperature: {temperatureData}");
            Console.WriteLine($"pH: {phData}");
            Console.WriteLine($"Humidity: {humidityData}");
            Console.WriteLine($"Swell: {swellData}");
            Console.WriteLine($"GPS: {gpsData}");
            Console.WriteLine($"-----------------------------------");

            
            Thread.Sleep(6000);
        }
    }

    
    public string ReadDataFromCsv(string filePath)
    {
        string lastLine = "";
        if (File.Exists(filePath))
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    lastLine = line;  // Armazena a última linha lida
                }
            }
        }
        else
        {
            Console.WriteLine($"Erro: o arquivo {filePath} não foi encontrado.");
        }
        return lastLine;
    }
}