using System;
using System.Collections.Generic;

class RandomCityRegion
{
    private static Dictionary<string, List<string>> regionCities = new Dictionary<string, List<string>>
    {
        { "Norte", new List<string> { "Viana do Castelo", "Braga", "Porto" } },
        { "Centro", new List<string> { "Aveiro", "Coimbra", "Leiria" } },
        { "Lisboa", new List<string> { "Lisboa", "Setúbal Norte" } },
        { "Alentejo", new List<string> { "Setúbal Sul", "Beja" } },
        { "Algarve", new List<string> { "Faro" } }
    };

    private static Dictionary<string, string> cityToRegion = new Dictionary<string, string>();
    static RandomCityRegion()
    {
        foreach (var kv in regionCities)
        {
            string region = kv.Key;
            foreach (string city in kv.Value)
            {
                cityToRegion[city] = region;
            }
        }
    }

    public static (string, string) GetRandomCityAndRegion()
    {
        List<string> citiesList = new List<string>(cityToRegion.Keys);
        Random random = new Random();
        string selectedCity = citiesList[random.Next(citiesList.Count)];
        string regionForCity = cityToRegion[selectedCity];
        return (selectedCity, regionForCity);
    }
}
