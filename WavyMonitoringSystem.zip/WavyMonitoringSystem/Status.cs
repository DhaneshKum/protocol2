using System;
using System.Globalization;

public class WavyStateManager
{
    public static void Status()
    {
        // Exibe a mensagem de solicitação ao administrador.
        Console.WriteLine("Deseja que o wavy fique ativo ou desativado?");
        Console.WriteLine("Digite A para ativar (Online) ou D para desativar (Offline):");

        // Lê e trata a resposta do administrador.
        string input = Console.ReadLine().Trim().ToUpper();
        string status = GetWavyStatus(input);

        // Obtém a data/hora atual no formato "YYYY-MM-DD-HH-mm-ss"
        string timestamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss", CultureInfo.InvariantCulture);

        // Exibe a mensagem formatada conforme o padrão solicitado
        Console.WriteLine($"Wavy_ID:Status:[{status}]:({timestamp})");
    }

    public static string GetWavyStatus(string input)
    {
        if (input == "A")
        {
            return "Online";
        }
        else if (input == "D")
        {
            return "Offline";
        }
        else
        {
            Console.WriteLine("Opção inválida. Por padrão, o wavy ficará Offline.");
            return "Offline";
        }
    }
}
