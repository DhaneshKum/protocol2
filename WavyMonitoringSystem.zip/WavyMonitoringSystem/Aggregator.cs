﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
using Grpc.Net.Client

public class Aggregator
{
    private TcpListener _listener;
    private static readonly object fileLock = new object();

    public void Start()
    {
        _listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 5001);
        _listener.Start();
        Console.WriteLine("AGREGADOR aguardando conexões...");

        while (true)
        {
            Console.WriteLine("Esperando por conexão na porta 5001...");
            TcpClient client = _listener.AcceptTcpClient();
            Console.WriteLine("Conexão aceita.");

            Thread clientThread = new Thread(() => HandleClient(client));
            clientThread.Start();
        }
    }

    private void HandleClient(TcpClient client)
    {
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[client.ReceiveBufferSize];
        int bytesRead = stream.Read(buffer, 0, buffer.Length);

        byte[] receivedFileBytes = new byte[bytesRead];
        Array.Copy(buffer, receivedFileBytes, bytesRead);

        string fileName = "received_sensor_data.csv";
        File.WriteAllBytes(fileName, receivedFileBytes);

        Console.WriteLine($"Arquivo recebido e salvo como {fileName}");

        ProcessAndSeparateData(fileName);

        client.Close();
    }

    public void ProcessAndSeparateData(string filePath)
    {
        string lastLine = null;
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                lastLine = line;
            }
        }

        if (lastLine != null)
        {
            string[] dataParts = lastLine.Split(';');

            if (dataParts.Length < 7)
            {
                Console.WriteLine("Erro: Dados incompletos recebidos.");
                return;
            }

            string temperatureData = dataParts[1].Split(':')[1];
            string phData = dataParts[2].Split(':')[1];
            string humidityData = dataParts[3].Split(':')[1];
            string swellData = dataParts[4].Split(':')[1];
            string gpsData = dataParts[5].Split(':')[1];
            string timestamp = dataParts[6].Split(':')[1];

            // Exibe apenas os dados atuais recebidos no terminal
            Console.WriteLine("=== Dados recebidos pelo Aggregator (atual) ===");
            Console.WriteLine($"Temperatura: {temperatureData}");
            Console.WriteLine($"pH: {phData}");
            Console.WriteLine($"Humidade: {humidityData}");
            Console.WriteLine($"Ondulação: {swellData}");
            Console.WriteLine($"GPS: {gpsData}");
            Console.WriteLine($"Timestamp: {timestamp}");
            Console.WriteLine("===============================================");

            // Salva cada tipo de dado em arquivos separados
            SaveDataToCsv("temperature.csv", temperatureData, timestamp);
            SaveDataToCsv("ph.csv", phData, timestamp);
            SaveDataToCsv("humidity.csv", humidityData, timestamp);
            SaveDataToCsv("swell.csv", swellData, timestamp);
            SaveDataToCsv("gps.csv", gpsData, timestamp);
        }
    }

    public void SaveDataToCsv(string fileName, string data, string timestamp)
    {
        if (!File.Exists(fileName))
        {
            using (StreamWriter writer = new StreamWriter(fileName, true))
            {
                writer.WriteLine($"{data}");
            }
        }
        else
        {
            lock (fileLock)
            {
                using (StreamWriter writer = new StreamWriter(fileName, true))
                {
                    writer.WriteLine($"{data}");
                }
            }
        }
    }
}

