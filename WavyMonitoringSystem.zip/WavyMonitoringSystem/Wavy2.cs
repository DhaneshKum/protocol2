﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;

public class Wavy2
{
    private string filePath = "sensor_data2.csv";

    public string GenerateSensorData()
    {
        (string selectedCity, string selectedRegion) = RandomCityRegion.GetRandomCityAndRegion();

        string temperature = TemperatureYearSimulator.SmoothRandomTemperature(DateTime.Now, selectedRegion).ToString("F2");
        string ph = PHSimulator.SmoothRandomPH(DateTime.Now, selectedRegion).ToString("F3");
        string humidity = HumidityYearSimulator.SmoothRandomHumidity(DateTime.Now, selectedRegion).ToString("F2");
        double swell = WaveSwellByRandomCitySimulator.SmoothRandomSwell(DateTime.Now);
        var gpsCoordinates = CoastalAreaGPSSimulator.GetCoastalGPS(selectedCity, selectedRegion);

        string status = WavyStateManager.GetWavyStatus("B"); // Use um ID diferente

        string message = $"Wavy_ID:{status};Temperature:{temperature};pH:{ph};Humidity:{humidity};Swell:{swell}m;GPS:({gpsCoordinates.lat:F6},{gpsCoordinates.lon:F6});Timestamp:{DateTime.Now:yyyy-MM-dd-HH-mm-ss}";

        SaveDataToCSV(message);
        SendData(filePath);

        return message;
    }

    public void SaveDataToCSV(string data)
    {
        string filePath = "sensor_data2.csv";
        if (!File.Exists(filePath))
        {
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(data);
            }
        }
        else
        {
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(data);
            }
        }
    }

    public void SendData(string filePath)
    {
        string aggregatorIp = "127.0.0.1";
        int aggregatorPort = 5002; // Porta diferente

        int retryAttempts = 5;
        int retryDelay = 2000;

        for (int attempt = 0; attempt < retryAttempts; attempt++)
        {
            try
            {
                using (TcpClient client = new TcpClient(aggregatorIp, aggregatorPort))
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] fileBytes = File.ReadAllBytes(filePath);
                    stream.Write(fileBytes, 0, fileBytes.Length);
                    Console.WriteLine("Dados enviados ao AGREGADOR 2");
                    return;
                }
            }
            catch (SocketException ex)
            {
                Console.WriteLine($"Erro ao conectar ao AGREGADOR 2 (tentativa {attempt + 1} de {retryAttempts}): {ex.Message}");
                if (attempt < retryAttempts - 1)
                {
                    Console.WriteLine($"Tentando novamente em {retryDelay / 1000} segundos...");
                    Thread.Sleep(retryDelay);
                }
                else
                {
                    Console.WriteLine("Falha ao conectar ao AGREGADOR 2 após várias tentativas.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro inesperado: {ex.Message}");
                break;
            }
        }
    }
}
