<?php
/**
 * Handles the display of "You Save" messages for WooCommerce products
 */
class PPC_Save_Message_Display
{
    /**
     * @var WC_Product|null
     */
    private $product = null;

    /**
     * Initialize hooks
     */
    public function __construct()
    {
        add_action('wp', [$this, 'init_hooks']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Initialize hooks based on product type
     */
    public function init_hooks() {
        if (!$this->can_display_message()) {
            return;
        }

        if ($this->product->is_type('variable')) {
            $this->init_variable_product_hooks();
        } else {
            $this->init_simple_product_hooks();
        }
    }

    /**
     * Initialize hooks for variable products
     */
    private function init_variable_product_hooks() {
        add_action('woocommerce_before_variations_form', [$this, 'maybe_display_variation_message_before']);
        add_action('woocommerce_after_variations_form', [$this, 'maybe_display_variation_message_after']);
    }

    /**
     * Initialize hooks for simple products
     */
    private function init_simple_product_hooks() {
        add_action('woocommerce_before_add_to_cart_button', [$this, 'maybe_display_message_before'], 5);
        add_action('woocommerce_after_add_to_cart_button', [$this, 'maybe_display_message_after'], 5);
    }

    /**
     * Check if we can display the message
     */
    private function can_display_message() {
        if (!function_exists('is_product') || !is_product() || !function_exists('wc_get_product')) {
            return false;
        }

        $this->init_product();
        return $this->product !== null;
    }

    /**
     * Initialize the product object
     */
    private function init_product() {
        if ($this->product !== null) {
            return;
        }

        $product_id = get_the_ID();
        if (!$product_id) {
            return;
        }

        $this->product = wc_get_product($product_id);
    }

    /**
     * Enqueue necessary scripts
     */
    public function enqueue_scripts() {
        if (!$this->can_display_message() || !$this->product->is_type('variable')) {
            return;
        }

        wp_enqueue_script(
            'ppc-variation-save-message',
            plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/admin/Js/variation-save-message.js',
            ['jquery', 'wc-add-to-cart-variation'],
            '1.0.0',
            true
        );

        wp_localize_script('ppc-variation-save-message', 'ppcSaveMessage', [
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'currency_pos' => get_option('woocommerce_currency_pos'),
            'enable_individual' => get_option('ppc_you_save_set_individual') === 'yes',
            'enable_global' => get_option('ppc_you_save_set_global') === 'yes',
            'custom_msg' => get_post_meta($this->product->get_id(), '_ppc_individual_custom_msg', true),
            'individual_position' => get_post_meta($this->product->get_id(), '_ppc_individual_position', true),
            'global_msg' => get_option('ppc_you_save_custom_msg', 'You Save'),
            'global_position' => get_option('ppc_you_save_display_position', 'after_cart')
        ]);
    }

    /**
     * Display message before add to cart button
     */
    public function maybe_display_message_before()
    {
        $this->output_message('before_cart');
    }

    /**
     * Display message after add to cart button
     */
    public function maybe_display_message_after()
    {
        $this->output_message('after_cart');
    }

    /**
     * Display variation message before variations form
     */
    public function maybe_display_variation_message_before()
    {
        $this->output_variation_message('before_cart');
    }

    /**
     * Display variation message after variations form
     */
    public function maybe_display_variation_message_after()
    {
        $this->output_variation_message('after_cart');
    }

    /**
     * Output the variation message
     */
    private function output_variation_message($position)
    {
        if (!$this->can_display_message() || !$this->product->is_type('variable')) {
            return;
        }

        $enable_global = get_option('ppc_you_save_set_global') === 'yes';
        $enable_individual = get_option('ppc_you_save_set_individual') === 'yes';

        if (!$enable_global && !$enable_individual) {
            return;
        }

        if (!$this->is_correct_message_position($position, $enable_individual)) {
            return;
        }

        echo '<div class="ppc-variation-save-message" style="display:none;margin:10px 0;font-weight:bold;color:#0a0;"></div>';
    }

    /**
     * Output the message for simple products
     */
    private function output_message($position)
    {
        if (!$this->can_display_message() || !$this->product->is_on_sale() || $this->product->is_type('variable')) {
            return;
        }

        $enable_global = get_option('ppc_you_save_set_global') === 'yes';
        $enable_individual = get_option('ppc_you_save_set_individual') === 'yes';
        $message = $this->get_message($position, $enable_individual, $enable_global);

        if ($message) {
            echo '<div class="ppc-you-save-message" style="margin:10px 0;font-weight:bold;color:#0a0;">' . $message . '</div>';
        }
    }

    /**
     * Get the appropriate message based on settings
     */
    private function get_message($position, $enable_individual, $enable_global) {
        $saved_amount = wc_price(
            (float) $this->product->get_regular_price() - (float) $this->product->get_sale_price()
        );

        // Show Individual Message
        if ($enable_individual) {
            $individual_position = get_post_meta($this->product->get_id(), '_ppc_individual_position', true);
            if ($individual_position !== $position) return '';

            $custom_msg = get_post_meta($this->product->get_id(), '_ppc_individual_custom_msg', true);
            if (!$custom_msg) return '';

            return esc_html($custom_msg) . ' ' . $saved_amount;
        }

        // Show Global Message
        if ($enable_global) {
            $global_position = get_option('ppc_you_save_display_position', 'after_cart');
            if ($global_position !== $position) return '';

            $prefix = get_option('ppc_you_save_custom_msg', 'You Save');
            return esc_html($prefix) . ' ' . $saved_amount;
        }

        return '';
    }

    /**
     * Check if this is the correct position to display the message
     */
    private function is_correct_message_position($position, $enable_individual) {
        if ($enable_individual) {
            $individual_position = get_post_meta($this->product->get_id(), '_ppc_individual_position', true);
            return $individual_position === $position;
        }
        
        $global_position = get_option('ppc_you_save_display_position', 'after_cart');
        return $global_position === $position;
    }
}

new PPC_Save_Message_Display();
