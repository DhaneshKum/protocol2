<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Variants_Tab {
    public function __construct() {
        // Only add product tab if individual settings are enabled
        if ('yes' === get_option('ppc_variants_set_individual', 'no')) {
            add_filter('woocommerce_product_data_tabs', [$this, 'add_variants_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'add_variants_fields']);
            add_action('woocommerce_process_product_meta', [$this, 'save_variants_fields']);
        }
    }

    /**
     * Add Variants Display tab to Product Data tabs
     */
    public function add_variants_tab($tabs) {
        $tabs['ppc_variants'] = [
            'label'    => __('Variants Display', 'product-page-customizer'),
            'target'   => 'ppc_variants_product_data',
            'class'    => ['show_if_variable'],  // Only show for variable products
            'priority' => 85,
        ];
        return $tabs;
    }

    /**
     * Add fields to Variants Display tab
     */
    public function add_variants_fields() {
        global $post;

        echo '<div id="ppc_variants_product_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        // Enable Variants Table for this product
        woocommerce_wp_checkbox([
            'id'          => '_ppc_enable_variants_table',
            'label'       => __('Show Variants Table', 'product-page-customizer'),
            'description' => __('Enable variants table display for this product.', 'product-page-customizer'),
            'desc_tip'    => true,
        ]);

        echo '</div>';
        echo '</div>';
    }

    /**
     * Save Variants Display fields
     */
    public function save_variants_fields($post_id) {
        $enable_variants = isset($_POST['_ppc_enable_variants_table']) ? 'yes' : 'no';
        update_post_meta($post_id, '_ppc_enable_variants_table', $enable_variants);
    }
}

new PPC_Product_Variants_Tab(); 