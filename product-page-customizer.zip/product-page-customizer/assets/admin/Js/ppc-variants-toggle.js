jQuery(document).ready(function ($) {
    // Function to show/hide global fields
    function toggleGlobalFields(show) {
        $('.ppc_variants_global_field').closest('tr').toggle(show);
    }

    // Enforce mutual exclusivity for variants display settings
    $('#ppc_variants_set_individual').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_global').prop('checked', false);
        }
    });

    $('#ppc_variants_set_global').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_individual').prop('checked', false);
        }
    });

    function toggleVariantsFields() {
        const isEnabled = $('#ppc_enable_variants_table').is(':checked');
        
        // Show/hide the option rows
        $('#ppc_variants_set_individual').closest('tr').toggle(isEnabled);
        $('#ppc_variants_set_global').closest('tr').toggle(isEnabled);
        
        // If disabling, uncheck both options
        if (!isEnabled) {
            $('#ppc_variants_set_individual').prop('checked', false);
            $('#ppc_variants_set_global').prop('checked', false);
        }
    }

    // Initial state
    toggleVariantsFields();

    // Toggle when main checkbox changes
    $('#ppc_enable_variants_table').on('change', toggleVariantsFields);

    // Add CSS to ensure smooth transitions
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .ppc_variants_global_field {
                transition: opacity 0.3s ease-in-out;
            }
            tr:has(.ppc_variants_global_field) {
                transition: all 0.3s ease-in-out;
            }
        `)
        .appendTo('head');
}); 