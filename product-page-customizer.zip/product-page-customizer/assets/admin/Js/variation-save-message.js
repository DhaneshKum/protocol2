/**
 * Handles the "You Save" message display for variable products
 */
jQuery(document).ready(function($) {
    'use strict';

    const $variationForm = $('form.variations_form');
    const $saveMessage = $('.ppc-variation-save-message');
    
    // Exit if required elements are not found
    if (!$variationForm.length || !$saveMessage.length) {
        return;
    }

    // Get variations data from the form
    const variationsData = $variationForm.data('product_variations');

    // Calculate and display initial price range savings if available
    if (variationsData && variationsData.length > 0) {
        let minRegularPrice = Infinity;
        let maxRegularPrice = -Infinity;
        let minSalePrice = Infinity;
        let maxSalePrice = -Infinity;
        let hasAnySale = false;

        // Find min and max prices
        variationsData.forEach(variation => {
            if (variation.display_regular_price) {
                minRegularPrice = Math.min(minRegularPrice, parseFloat(variation.display_regular_price));
                maxRegularPrice = Math.max(maxRegularPrice, parseFloat(variation.display_regular_price));
            }
            if (variation.display_price) {
                minSalePrice = Math.min(minSalePrice, parseFloat(variation.display_price));
                maxSalePrice = Math.max(maxSalePrice, parseFloat(variation.display_price));
            }
            if (variation.display_regular_price > variation.display_price) {
                hasAnySale = true;
            }
        });

        // If any variation is on sale, show the initial range message
        if (hasAnySale) {
            const minSaving = minRegularPrice - minSalePrice;
            const maxSaving = maxRegularPrice - maxSalePrice;
            let message = '';

            if (ppcSaveMessage.enable_individual && ppcSaveMessage.custom_msg) {
                message = ppcSaveMessage.custom_msg + ' ';
            } else if (ppcSaveMessage.enable_global) {
                message = ppcSaveMessage.global_msg + ' ';
            }

            if (message) {
                if (minSaving === maxSaving) {
                    message += formatPrice(minSaving);
                } else {
                    message += formatPrice(minSaving) + ' - ' + formatPrice(maxSaving);
                }
                $saveMessage.html(message).show();
            }
        }
    }

    /**
     * Handles showing the save message when a variation is selected
     */
    $variationForm.on('show_variation', function(event, variation) {
        if (!variation) {
            $saveMessage.hide();
            return;
        }

        const regularPrice = parseFloat(variation.display_regular_price);
        const salePrice = parseFloat(variation.display_price);
        
        // Only show message if there's a saving
        if (regularPrice > salePrice) {
            const savedAmount = regularPrice - salePrice;
            const currentPosition = getCurrentPosition();
            let message = '';

            // Check for individual message first
            if (ppcSaveMessage.enable_individual && 
                ppcSaveMessage.custom_msg && 
                ppcSaveMessage.individual_position === currentPosition) {
                message = ppcSaveMessage.custom_msg + ' ' + formatPrice(savedAmount);
            }
            // Fall back to global message
            else if (ppcSaveMessage.enable_global && 
                     ppcSaveMessage.global_position === currentPosition) {
                message = ppcSaveMessage.global_msg + ' ' + formatPrice(savedAmount);
            }

            if (message) {
                // Add original and current price information
                message += '<br><small>(Original price: ' + formatPrice(regularPrice) + 
                          ', Current price: ' + formatPrice(salePrice) + ')</small>';
                $saveMessage.html(message).show();
            } else {
                $saveMessage.hide();
            }
        } else {
            $saveMessage.hide();
        }
    });

    /**
     * Reset to price range savings when variation is hidden
     */
    $variationForm.on('hide_variation reset_data', function() {
        if (variationsData && variationsData.length > 0) {
            // Recalculate price range savings
            let minRegularPrice = Infinity;
            let maxRegularPrice = -Infinity;
            let minSalePrice = Infinity;
            let maxSalePrice = -Infinity;
            let hasAnySale = false;

            variationsData.forEach(variation => {
                if (variation.display_regular_price) {
                    minRegularPrice = Math.min(minRegularPrice, parseFloat(variation.display_regular_price));
                    maxRegularPrice = Math.max(maxRegularPrice, parseFloat(variation.display_regular_price));
                }
                if (variation.display_price) {
                    minSalePrice = Math.min(minSalePrice, parseFloat(variation.display_price));
                    maxSalePrice = Math.max(maxSalePrice, parseFloat(variation.display_price));
                }
                if (variation.display_regular_price > variation.display_price) {
                    hasAnySale = true;
                }
            });

            if (hasAnySale) {
                const minSaving = minRegularPrice - minSalePrice;
                const maxSaving = maxRegularPrice - maxSalePrice;
                let message = '';

                if (ppcSaveMessage.enable_individual && ppcSaveMessage.custom_msg) {
                    message = ppcSaveMessage.custom_msg + ' ';
                } else if (ppcSaveMessage.enable_global) {
                    message = ppcSaveMessage.global_msg + ' ';
                }

                if (message) {
                    if (minSaving === maxSaving) {
                        message += formatPrice(minSaving);
                    } else {
                        message += formatPrice(minSaving) + ' - ' + formatPrice(maxSaving);
                    }
                    $saveMessage.html(message).show();
                }
            } else {
                $saveMessage.hide();
            }
        } else {
            $saveMessage.hide();
        }
    });

    /**
     * Determines if the message is before or after the add to cart button
     * @returns {string} 'before_cart' or 'after_cart'
     */
    function getCurrentPosition() {
        const $addToCartBtn = $('.single_add_to_cart_button');
        if (!$addToCartBtn.length || !$saveMessage.length) {
            return '';
        }

        const messagePosition = $saveMessage.offset().top;
        const buttonPosition = $addToCartBtn.offset().top;
        
        return messagePosition < buttonPosition ? 'before_cart' : 'after_cart';
    }

    /**
     * Formats the price according to WooCommerce settings
     * @param {number} price - The price to format
     * @returns {string} Formatted price with currency symbol
     */
    function formatPrice(price) {
        price = Number(price).toFixed(2);
        
        switch (ppcSaveMessage.currency_pos) {
            case 'left':
                return ppcSaveMessage.currency_symbol + price;
            case 'right':
                return price + ppcSaveMessage.currency_symbol;
            case 'left_space':
                return ppcSaveMessage.currency_symbol + ' ' + price;
            case 'right_space':
                return price + ' ' + ppcSaveMessage.currency_symbol;
            default:
                return price;
        }
    }
}); 