jQuery(function ($) {
    function toggleMinMaxFields() {
        if ($('#ppc_enable_min_max_order').is(':checked')) {
            $('.ppc_min_max_fields').closest('tr').show();
        } else {
            $('.ppc_min_max_fields').closest('tr').hide();
        }
    }

    toggleMinMaxFields();

    // Toggle when min/max checkbox changes
    $('#ppc_enable_min_max_order').on('change', toggleMinMaxFields);
});
