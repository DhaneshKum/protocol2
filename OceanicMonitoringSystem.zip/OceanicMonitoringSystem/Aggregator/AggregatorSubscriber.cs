using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading.Tasks;
using Grpc.Net.Client;
using PreprocessingService;
using SharedModels.Models;

public class AggregatorSubscriber : IDisposable
{
    private readonly string _aggregatorId;
    private IConnection _connection;
    private IModel _channel;
    private string _queueName;
    private bool _disposed = false;
    private readonly GrpcChannel _grpcChannel;
    private readonly Preprocessing.PreprocessingClient _preprocessingClient;

    public AggregatorSubscriber(string aggregatorId)
    {
        _aggregatorId = aggregatorId;
        
        // RabbitMQ setup
        ConnectToRabbitMQ();
        
        // gRPC setup
        _grpcChannel = GrpcChannel.ForAddress("https://localhost:5001");
        _preprocessingClient = new Preprocessing.PreprocessingClient(_grpcChannel);
    }

    private void ConnectToRabbitMQ()
    {
        var factory = new ConnectionFactory()
        {
            HostName = "localhost",
            AutomaticRecoveryEnabled = true,
            NetworkRecoveryInterval = TimeSpan.FromSeconds(10)
        };

        _connection = factory.CreateConnection();
        _connection.ConnectionShutdown += (sender, e) => 
        {
            Console.WriteLine("RabbitMQ connection shutdown. Attempting to reconnect...");
            Task.Delay(5000).ContinueWith(t => ConnectToRabbitMQ());
        };

        _channel = _connection.CreateModel();
        _channel.ExchangeDeclare(
            exchange: "oceanic_data", 
            type: ExchangeType.Fanout,
            durable: true,
            autoDelete: false);
        
        _channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);
        
        _queueName = _channel.QueueDeclare().QueueName;
        _channel.QueueBind(
            queue: _queueName,
            exchange: "oceanic_data",
            routingKey: "");

        Console.WriteLine("RabbitMQ connection established");
    }

    public void StartConsuming()
    {
        var consumer = new EventingBasicConsumer(_channel);
        consumer.Received += async (model, ea) =>
        {
            try
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                var data = System.Text.Json.JsonSerializer.Deserialize<WavyData>(message);
                
                Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Aggregator {_aggregatorId} received data from {data.WavyId}");

                // Process with gRPC
                var response = await _preprocessingClient.PreprocessDataAsync(
                    new PreprocessRequest
                    {
                        WavyId = data.WavyId,
                        Timestamp = data.Timestamp,
                        Temperature = (float)data.Temperature,
                        Salinity = (float)data.Salinity,
                        Ph = (float)data.PH,
                        Turbidity = (float)data.Turbidity
                    });
                
                Console.WriteLine($"Preprocessed data for {data.WavyId}. Status: {response.Status}");
                
                _channel.BasicAck(deliveryTag: ea.DeliveryTag, multiple: false);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Processing failed: {ex.Message}");
                _channel.BasicReject(deliveryTag: ea.DeliveryTag, requeue: false);
            }
        };

        _channel.BasicConsume(
            queue: _queueName,
            autoAck: false,
            consumer: consumer);

        Console.WriteLine($"Aggregator {_aggregatorId} started consuming...");
    }

    public void Dispose()
    {
        _disposed = true;
        _channel?.Close();
        _connection?.Close();
        _grpcChannel?.Dispose();
    }
}