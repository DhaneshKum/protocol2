using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("Starting Aggregator...");
        
        var aggregatorId = args.Length > 0 ? args[0] : "AGG_" + Guid.NewGuid().ToString()[..4];
        Console.WriteLine($"Aggregator ID: {aggregatorId}");
        
        using var aggregator = new AggregatorSubscriber(aggregatorId);
        
        Console.CancelKeyPress += (sender, e) => 
        {
            Console.WriteLine("Shutting down...");
            aggregator.Dispose();
            Environment.Exit(0);
        };
        
        aggregator.StartConsuming();
        await Task.Delay(-1); // Keep running
    }
}