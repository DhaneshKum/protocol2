using System.Threading.Tasks;
using Grpc.Core;
using AnalysisService;
using SharedModels.Models;

namespace AnalysisService.Services
{
    public class AnalysisService : Analysis.AnalysisBase
    {
        public override Task<AnalysisResponse> PerformAnalysis(AnalysisRequest request, ServerCallContext context)
        {
            try
            {
                bool isAnomaly = request.Temperature > 0.9f || request.Salinity < 0.1f || 
                                request.Ph > 0.9f || request.Turbidity > 0.8f;
                
                var response = new AnalysisResponse
                {
                    AnalysisId = Guid.NewGuid().ToString(),
                    WavyId = request.WavyId,
                    Timestamp = request.Timestamp,
                    Result = isAnomaly ? "ANOMALY" : "NORMAL",
                    Confidence = isAnomaly ? 0.85f : 0.95f,
                    Details = isAnomaly ? "One or more parameters outside normal range" : "All parameters normal",
                    AnalysisTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
                };

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Analysis failed: {ex.Message}"));
            }
        }
    }
}