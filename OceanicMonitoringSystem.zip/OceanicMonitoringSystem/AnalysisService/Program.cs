using Microsoft.AspNetCore.Server.Kestrel.Core;
using AnalysisService;

var builder = WebApplication.CreateBuilder(args);

// Configure Kestrel for gRPC
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenLocalhost(5002, o => o.Protocols = HttpProtocols.Http2);
});

// Add services to the container.
builder.Services.AddGrpc();

var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<Services.AnalysisService>();
app.MapGet("/", () => "Analysis gRPC Service is running.");

Console.WriteLine("Starting Analysis Service on port 5002");
app.Run();