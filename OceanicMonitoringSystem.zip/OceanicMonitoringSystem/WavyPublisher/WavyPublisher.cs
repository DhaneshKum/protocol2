using RabbitMQ.Client;
using RabbitMQ.Client.Exceptions;
using System;
using System.Text;
using System.Threading;
using SharedModels.Models;

public class WavyPublisher : IDisposable
{
    private readonly string _wavyId;
    private IConnection _connection;
    private IModel _channel;
    private ConnectionFactory _factory;
    private readonly object _lock = new object();
    private bool _disposed = false;

    public WavyPublisher(string wavyId)
    {
        _wavyId = wavyId;
        _factory = new ConnectionFactory() 
        { 
            HostName = "localhost",
            AutomaticRecoveryEnabled = true,
            NetworkRecoveryInterval = TimeSpan.FromSeconds(10)
        };
        EnsureConnection();
    }

    private void EnsureConnection()
    {
        lock (_lock)
        {
            if (_connection?.IsOpen == true) return;

            try
            {
                _connection?.Dispose();
                _channel?.Dispose();

                _connection = _factory.CreateConnection();
                _connection.ConnectionShutdown += (sender, e) => 
                {
                    Console.WriteLine("Connection shutdown. Attempting to reconnect...");
                    Thread.Sleep(5000);
                    EnsureConnection();
                };

                _channel = _connection.CreateModel();
                _channel.ExchangeDeclare(
                    exchange: "oceanic_data", 
                    type: ExchangeType.Fanout,
                    durable: true,
                    autoDelete: false);
                
                Console.WriteLine("RabbitMQ connection established");
            }
            catch (BrokerUnreachableException)
            {
                Console.WriteLine("RabbitMQ broker unreachable. Retrying in 5 seconds...");
                Thread.Sleep(5000);
                EnsureConnection();
            }
        }
    }

    public void PublishData()
    {
        var random = new Random();
        
        while (!_disposed)
        {
            try
            {
                if (_channel?.IsOpen != true)
                {
                    EnsureConnection();
                    continue;
                }

                var data = new WavyData
                {
                    WavyId = _wavyId,
                    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                    Temperature = Math.Round(15 + random.NextDouble() * 15, 2),
                    Salinity = Math.Round(30 + random.NextDouble() * 10, 2),
                    PH = Math.Round(7 + random.NextDouble() * 2, 2),
                    Turbidity = Math.Round(random.NextDouble() * 10, 2)
                };

                var message = System.Text.Json.JsonSerializer.Serialize(data);
                var body = Encoding.UTF8.GetBytes(message);

                _channel.BasicPublish(
                    exchange: "oceanic_data",
                    routingKey: "",
                    basicProperties: null,
                    body: body);

                Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] WAVY {_wavyId} published data");
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Publishing error: {ex.Message}");
                Thread.Sleep(5000);
                EnsureConnection();
            }
        }
    }

    public void Dispose()
    {
        _disposed = true;
        _channel?.Close();
        _connection?.Close();
        _channel?.Dispose();
        _connection?.Dispose();
    }
}