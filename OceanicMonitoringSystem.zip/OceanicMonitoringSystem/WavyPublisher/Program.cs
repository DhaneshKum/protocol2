using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Starting WAVY Publisher...");
        
        var publisherId = args.Length > 0 ? args[0] : "WAVY_" + Guid.NewGuid().ToString()[..4];
        Console.WriteLine($"Publisher ID: {publisherId}");
        
        using var publisher = new WavyPublisher(publisherId);
        
        Console.CancelKeyPress += (sender, e) => 
        {
            Console.WriteLine("Shutting down...");
            publisher.Dispose();
            Environment.Exit(0);
        };
        
        publisher.PublishData();
    }
}