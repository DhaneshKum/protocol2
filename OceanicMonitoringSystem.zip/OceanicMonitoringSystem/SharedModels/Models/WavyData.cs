using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SharedModels.Models
{
    public class WavyData
    {
        public string WavyId { get; set; }
        public long Timestamp { get; set; }
        public double Temperature { get; set; }
        public double Salinity { get; set; }
        public double PH { get; set; }
        public double Turbidity { get; set; }
    }

    public class ProcessedData
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        
        public string WavyId { get; set; }
        public long Timestamp { get; set; }
        public float NormalizedTemperature { get; set; }
        public float NormalizedSalinity { get; set; }
        public float NormalizedPh { get; set; }
        public float NormalizedTurbidity { get; set; }
        public string Status { get; set; }
        public long ProcessedTime { get; set; }
    }

    public class AnalysisResult
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        
        public string AnalysisId { get; set; }
        public string WavyId { get; set; }
        public long Timestamp { get; set; }
        public string Result { get; set; }
        public float Confidence { get; set; }
        public string Details { get; set; }
        public long AnalysisTime { get; set; }
    }
}