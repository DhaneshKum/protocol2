using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SharedModels.Models
{
    public class ProcessedData
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        
        [BsonElement("wavyId")]
        public string WavyId { get; set; }
        
        [BsonElement("timestamp")]
        public long Timestamp { get; set; }
        
        [BsonElement("normalizedTemperature")]
        public float NormalizedTemperature { get; set; }
        
        [BsonElement("normalizedSalinity")]
        public float NormalizedSalinity { get; set; }
        
        [BsonElement("normalizedPh")]
        public float NormalizedPh { get; set; }
        
        [BsonElement("normalizedTurbidity")]
        public float NormalizedTurbidity { get; set; }
        
        [BsonElement("status")]
        public string Status { get; set; }
        
        [BsonElement("processedTime")]
        public long ProcessedTime { get; set; }
        
        [BsonElement("createdAt")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}