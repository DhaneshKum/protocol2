using System;
using System.Threading.Tasks;
using SharedModels.Models;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("Starting Oceanic Server...");
        
        using var server = new OceanicServer();
        
        Console.CancelKeyPress += (sender, e) => 
        {
            Console.WriteLine("Shutting down...");
            server.Dispose();
            Environment.Exit(0);
        };

        // Simulate receiving processed data (in real system this would come from aggregators)
        while (true)
        {
            var random = new Random();
            var data = new ProcessedData
            {
                WavyId = "WAVY_" + random.Next(1, 100),
                Timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                NormalizedTemperature = (float)random.NextDouble(),
                NormalizedSalinity = (float)random.NextDouble(),
                NormalizedPh = (float)random.NextDouble(),
                NormalizedTurbidity = (float)random.NextDouble(),
                Status = "PROCESSED",
                ProcessedTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
            };

            await server.ProcessAndStoreData(data);
            await Task.Delay(3000);
        }
    }
}