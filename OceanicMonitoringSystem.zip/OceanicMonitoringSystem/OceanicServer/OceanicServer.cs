using System;
using System.Threading.Tasks;
using MongoDB.Driver;
using Grpc.Net.Client;
using AnalysisService;
using SharedModels.Models;

public class OceanicServer : IDisposable
{
    private readonly IMongoCollection<ProcessedData> _dataCollection;
    private readonly IMongoCollection<AnalysisResult> _analysisCollection;
    private readonly GrpcChannel _analysisChannel;
    private readonly Analysis.AnalysisClient _analysisClient;

    public OceanicServer()
    {
        // MongoDB setup
        var client = new MongoClient("mongodb://localhost:27017");
        var database = client.GetDatabase("oceanic_monitoring");
        _dataCollection = database.GetCollection<ProcessedData>("sensor_data");
        _analysisCollection = database.GetCollection<AnalysisResult>("analysis_results");
        
        // Create indexes
        _dataCollection.Indexes.CreateOne(
            new CreateIndexModel<ProcessedData>(
                Builders<ProcessedData>.IndexKeys.Ascending(d => d.WavyId)));
                
        _analysisCollection.Indexes.CreateOne(
            new CreateIndexModel<AnalysisResult>(
                Builders<AnalysisResult>.IndexKeys.Ascending(a => a.WavyId)));
        
        // gRPC setup
        _analysisChannel = GrpcChannel.ForAddress("https://localhost:5002");
        _analysisClient = new Analysis.AnalysisClient(_analysisChannel);
    }

    public async Task ProcessAndStoreData(ProcessedData data)
    {
        try
        {
            // Store raw processed data
            await _dataCollection.InsertOneAsync(data);
            Console.WriteLine($"Stored data from {data.WavyId} at {DateTimeOffset.FromUnixTimeSeconds(data.Timestamp)}");
            
            // Prepare analysis request
            var request = new AnalysisRequest
            {
                WavyId = data.WavyId,
                Timestamp = data.Timestamp,
                Temperature = data.NormalizedTemperature,
                Salinity = data.NormalizedSalinity,
                Ph = data.NormalizedPh,
                Turbidity = data.NormalizedTurbidity
            };
            
            // Get analysis
            var analysis = await _analysisClient.PerformAnalysisAsync(request);
            
            // Store analysis result
            var result = new AnalysisResult
            {
                AnalysisId = analysis.AnalysisId,
                WavyId = analysis.WavyId,
                Timestamp = analysis.Timestamp,
                Result = analysis.Result,
                Confidence = analysis.Confidence,
                Details = analysis.Details,
                AnalysisTime = analysis.AnalysisTime
            };
            
            await _analysisCollection.InsertOneAsync(result);
            Console.WriteLine($"Stored analysis for {data.WavyId}. Result: {analysis.Result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error processing data: {ex.Message}");
        }
    }

    public void Dispose()
    {
        _analysisChannel?.Dispose();
    }
}