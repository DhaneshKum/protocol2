using Microsoft.AspNetCore.Server.Kestrel.Core;
using PreprocessingService;

var builder = WebApplication.CreateBuilder(args);

// Configure Kestrel for gRPC
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenLocalhost(5001, o => o.Protocols = HttpProtocols.Http2);
});

// Add services to the container.
builder.Services.AddGrpc();

var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<Services.PreprocessingService>();
app.MapGet("/", () => "Preprocessing gRPC Service is running.");

Console.WriteLine("Starting Preprocessing Service on port 5001");
app.Run();