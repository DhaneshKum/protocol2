using System.Threading.Tasks;
using Grpc.Core;
using PreprocessingService;
using SharedModels.Models;

namespace PreprocessingService.Services
{
    public class PreprocessingService : Preprocessing.PreprocessingBase
    {
        public override Task<PreprocessResponse> PreprocessData(PreprocessRequest request, ServerCallContext context)
        {
            try
            {
                // Convert timestamp to DateTime
                var timestamp = DateTimeOffset.FromUnixTimeSeconds(request.Timestamp);
                
                // Create response with normalized values
                var response = new PreprocessResponse
                {
                    WavyId = request.WavyId,
                    Timestamp = request.Timestamp,
                    NormalizedTemperature = (request.Temperature - 15f) / 15f,
                    NormalizedSalinity = (request.Salinity - 30f) / 10f,
                    NormalizedPh = (request.Ph - 7f) / 2f,
                    NormalizedTurbidity = request.Turbidity / 10f,
                    Status = "OK",
                    ProcessedTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
                };

                return Task.FromResult(response);
            }
            catch (Exception ex)
            {
                throw new RpcException(new Status(StatusCode.Internal, $"Preprocessing failed: {ex.Message}"));
            }
        }
    }
}